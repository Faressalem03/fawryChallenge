package fawrychallenge;

/**
 *
 * @author fares salem
 */
public interface Shippable {
    String getName();
    double getWeight();
}


